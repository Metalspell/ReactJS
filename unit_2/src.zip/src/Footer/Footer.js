import Nav from "../Header/Nav";

function Footer() {
  return (
    <h3>site_name</h3>,
    <Nav />
  );
}

export default Footer;