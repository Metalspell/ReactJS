
function Nav(props) {
  let data = props.navData;
  const listItem = data.map(item => <li><a href={item.link}>{item.text}</a></li>);
  return (
    <>
      <nav>
        <ul className="main-navigation">
          {listItem}
        </ul>
      </nav>
    </>
  );
}

export default Nav;